function showInterstitialAdMinigame() {
	MiniGameAds.hideBanner();
    if(MiniGameAds.isInterstitialReady()) {
        MiniGameAds.showInterstitial();
    } 
}

function showBannerAdMinigame() {
	if(MiniGameAds.isBannerReady()) {
        MiniGameAds.showBanner();
    } 
}

function showRewardedVideoAdMinigame(callback) {
	MiniGameAds.hideBanner();
	if(MiniGameAds.isRewardvideoReady()){
        MiniGameAds.showRewardedVideo().then(()=>{
			console.info("====> show RewardedVideo success");
			callback();
		}).catch(e => {
			console.error("====> show RewardedVideo error: " + e.message);
		});
    }
}


minigame.initializeAsync().then(function () {
    minigame.startGameAsync().then(function () {
        showInterstitialAdMinigame()
        var canvas = document.getElementById('openfl-content');
        canvas.style.display = "block";
    });
});

